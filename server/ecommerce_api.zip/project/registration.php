<?php
	include_once 'config.php';
	$conn = new DbConnect(); 	

	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	header("Content-Type: application/json; charset=UTF-8");
	
	$id= ''; 
     $id=$_POST['id'];
    $mobile=$_POST['mobile'];
	$email=$_POST['email'];
    $address=$_POST['address'];
     $pass = $_POST['pass']; 
	 $role = $_POST['role'] ;


$sql="INSERT INTO `register` (`id`, `mobile`, `email`, `address`, `pass`, `role`) VALUES ('$id', '$mobile', '$email','$address','$pass', '$role')";
$result = mysqli_query($conn->getDb(),$sql);			
		
	if ($result==1)
	{
		$add="true";
	}
	else
	{
		$add="false";
	}
	echo json_encode(array('userexists'=>$add));
			  
?>





