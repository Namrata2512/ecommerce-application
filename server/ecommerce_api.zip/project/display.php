<?php 
$conn=mysqli_connect('localhost','root','','ecommerce');
// include_once 'config.php';
// // $conn = new DbConnect(); 	

$query="select * from register";
if($fireq=mysqli_query($conn, $query)){
    $cr=0;

while($res=mysqli_fetch_assoc($fireq))
{
    $users[$cr]['id']=$res['id'];
    $users[$cr]['mobile']=$res['mobile'];
    $users[$cr]['email']=$res['email'];
    $users[$cr]['address']=$res['address'];
    $users[$cr]['pass']=$res['pass'];
    $users[$cr]['role']=$res['role'];
    $cr++;}
  
 echo json_encode($users);
}
else{
    // http_response_code(404);
}

?>


<?php

?>