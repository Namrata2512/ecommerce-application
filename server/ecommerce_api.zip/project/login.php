<?php
	
require 'config.php';
	$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
	
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	header("Content-Type: application/json; charset=UTF-8");

$email = $_POST['email'];
$pass = $_POST['pass'];
$role=$_POST['role'];

$sql = "select * from register where email = '$email' and pass= '$pass' and  role='$role'";  
$result = mysqli_query($conn, $sql);
// $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  

$row = mysqli_num_rows($result);  
 if($row ==1) {
		  $arr=array();
	while ($row =mysqli_fetch_assoc($result)){
		$arr[]=$row;
	}	

      echo json_encode($arr);
	  mysqli_close($conn);
	  }
	  else{
		        echo json_encode(null);

	  }
	  

	  


?>